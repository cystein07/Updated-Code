const reservationsRouter = require('./routes/reservations');
const managerRouter = require('./routes/manager');

app.use('/reservations', reservationsRouter);
app.use('/manager', managerRouter);
