const express = require('express');
const router = express.Router();
const db = require('../db');

// Get user’s reservations
router.get('/:userId', (req, res) => {
    const userId = req.params.userId;
    const query = `
        SELECT r.reservation_id, o.name AS office_name, rm.room_id, tr.record_starttime, tr.record_endtime, r.reservation_starttime, r.reservation_endtime
        FROM reservation r
        JOIN room rm ON r.room_id = rm.room_id
        JOIN office o ON rm.office_id = o.office_id
        JOIN time_record tr ON r.time_record_id = tr.record_id
        WHERE r.user_id = ?`;
    db.query(query, [userId], (err, results) => {
        if (err) throw err;
        res.render('userReservations', { reservations: results });
    });
});

// Delete reservation
router.post('/delete/:id', (req, res) => {
    const reservationId = req.params.id;
    const userId = req.body.userId; // Assuming you're passing user ID
    const query = 'DELETE FROM reservation WHERE reservation_id = ? AND user_id = ?';
    db.query(query, [reservationId, userId], (err) => {
        if (err) throw err;
        res.redirect('/reservations/' + userId); // Redirect back to the user's reservations page
    });
});

module.exports = router;
