-- This makes sure that foreign_key constraints are observed and that errors will be thrown for violations
PRAGMA foreign_keys=ON;

BEGIN TRANSACTION;

-- Table for storing office information with number_of_rooms
CREATE TABLE IF NOT EXISTS office (
    office_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT,
    number_of_rooms INTEGER NOT NULL
);

-- Table for storing room information
CREATE TABLE IF NOT EXISTS room (
    room_id INTEGER PRIMARY KEY AUTOINCREMENT,
    office_id INTEGER NOT NULL,
    FOREIGN KEY (office_id) REFERENCES office (office_id)
);

-- Table for storing time records for each room
CREATE TABLE IF NOT EXISTS time_record (
    record_id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER NOT NULL,
    record_starttime TIMESTAMP NOT NULL,
    record_endtime TIMESTAMP NOT NULL,
    FOREIGN KEY (room_id) REFERENCES room (room_id)
);

-- Table for storing reservations
CREATE TABLE IF NOT EXISTS reservation (
    reservation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER NOT NULL,
    time_record_id INTEGER NOT NULL,
    reservation_starttime TIMESTAMP NOT NULL,
    reservation_endtime TIMESTAMP NOT NULL,
    user_id INTEGER,
    FOREIGN KEY (room_id) REFERENCES room (room_id),
    FOREIGN KEY (time_record_id) REFERENCES time_record (record_id),
    FOREIGN KEY (user_id) REFERENCES user (user_id)
);

-- Table for storing user information
CREATE TABLE IF NOT EXISTS user (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    name TEXT
);

COMMIT;