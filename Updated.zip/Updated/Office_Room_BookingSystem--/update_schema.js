const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');

// Read the SQL file
const sql = fs.readFileSync('update_schema.sql', 'utf8');

// Connect to the database
let db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) {
    console.error(err.message);
    throw err;
  }
  console.log('Connected to the SQLite database.');
});

// Execute the SQL commands
db.exec(sql, (err) => {
  if (err) {
    console.error('Error executing SQL:', err.message);
    if (err.message.includes('duplicate column name')) {
      console.log('The user_id column might already exist in the reservation table. This is not an issue.');
    }
  } else {
    console.log('Database schema updated successfully.');
  }

  // Close the database connection
  db.close((err) => {
    if (err) {
      console.error(err.message);
    }
    console.log('Closed the database connection.');
  });
});